ZenLib - http://zenlib.sourceforge.net
Copyright (c) 2005-2012, Jerome Martinez, zen@mediaarea.net

This program is freeware under zlib licence conditions.
See Licence.txt for more information
